"use strict";
/* ==========================================================================
   site.config.js – EchtJetzt: Struktur der Website (nur fuer den Build,
   node tools/build.js). Definiert Navigation, Kategorien und den Aufbau
   der Startseite. Aenderungen hier + erneuter Build genuegen, um Nav/
   Startseite umzustellen - kein HTML wird von Hand gepflegt.
   ========================================================================== */
module.exports = {
  siteType: "news",
  hasBreakingBar: true,
  nav: [
    { label: "Rechner", external: "https://geldhirn.de" },
    { label: "News", category: "news" },
    { label: "Geld", category: "geld" },
    { label: "Verbraucher", category: "verbraucher" },
    { label: "Immobilien", category: "immobilien" },
    { label: "Energie", category: "energie" },
    { label: "Auto", category: "auto" },
    { label: "Promis", category: "promis" },
    { label: "Good News", category: "good-news" },
    { label: "Technik", category: "technik" },
    { label: "Reisen", category: "reisen" }
  ],
  categories: [
    { id: "news", slug: "news", label: "News", description: "Was heute wichtig ist – kurz und eingeordnet.", icon: "starburst" },
    { id: "geld", slug: "geld", label: "Geld", description: "Verbraucherpreise, Finanzen und Alltagskosten im Blick.", icon: "coin" },
    { id: "verbraucher", slug: "verbraucher", label: "Verbraucher", description: "Rechte, Pflichten und Fallstricke im Alltag.", icon: "shield" },
    { id: "immobilien", slug: "immobilien", label: "Immobilien", description: "Preise, Zinsen und Trends rund ums Wohnen.", icon: "house" },
    { id: "energie", slug: "energie", label: "Energie", description: "Strom-, Gas- und Heizkosten verstaendlich erklaert.", icon: "bolt" },
    { id: "auto", slug: "auto", label: "Auto", description: "Mobilitaet, E-Autos und was sie wirklich kosten.", icon: "car" },
    { id: "promis", slug: "promis", label: "Promis & Leute", description: "Vermoegen, Haeuser und Luxus – mit Verbraucherblick.", icon: "crown" },
    { id: "good-news", slug: "good-news", label: "Good News", description: "Positive Nachrichten zur Abwechslung.", icon: "heart" },
    { id: "kurios", slug: "kurios", label: "Kurios & unglaublich", description: "Ungewoehnliche Meldungen aus aller Welt.", icon: "question" },
    { id: "technik", slug: "technik", label: "Technik", description: "Neue Geraete, KI und was sich wirklich lohnt.", icon: "chip" },
    { id: "reisen", slug: "reisen", label: "Reisen", description: "Reisetrends, Flugpreise und Urlaubswissen.", icon: "plane" }
  ],
  /* Reihenfolge auf ausdrücklichen Wunsch festgelegt: News zuerst, dann
     Promis, dann Good News, dann Geld, danach alles Weitere. */
  homepageSections: [
    { id: "news", title: "News", categories: ["news", "kurios"], max: 3 },
    { id: "promis-vermoegen", title: "Promis, Vermoegen & Luxus", categories: ["promis"], max: 3 },
    { id: "good-news", title: "Good News", categories: ["good-news"], max: 3 },
    { id: "geld", title: "Geld", categories: ["geld"], max: 3 },
    { id: "auto-mobilitaet", title: "Auto & Mobilitaet", categories: ["auto"], max: 3 },
    { id: "reisen", title: "Reisen", categories: ["reisen"], max: 3 },
    { id: "verbraucher", title: "Verbraucher", categories: ["verbraucher"], max: 3 },
    { id: "immobilien-wohnen", title: "Immobilien & Wohnen", categories: ["immobilien"], max: 3 },
    { id: "energie-preise", title: "Energie & Preise", categories: ["energie"], max: 3 },
    { id: "technik", title: "Technik", categories: ["technik"], max: 3 },
    { id: "meistgelesen", title: "Meistgelesen", categories: null, max: 5, mode: "trending" },
    { id: "neueste", title: "Neueste Meldungen", categories: null, max: 8, mode: "newest" }
  ]
};
