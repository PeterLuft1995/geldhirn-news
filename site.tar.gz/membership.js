"use strict";
/* ==========================================================================
   membership.js – Pro-/Ad-Free-Future-Hook
   ==========================================================================
   Aktuell existiert noch KEIN echtes, domainuebergreifendes Login-System.
   Diese Datei taeuscht daher NICHTS vor: isProMember() liefert im MVP immer
   false, damit Werbung normal angezeigt wird. Die Architektur ist aber bereits
   so vorbereitet, dass ein echter Pro-Status spaeter ohne Umbau der Seiten
   eingehaengt werden kann.

   ZUKUNFTSARCHITEKTUR (noch nicht aktiv):

     Shared Account / SSO
            |
     zentrale Authentifizierung (z.B. das bestehende Supabase-Projekt
     von EchtKosten, ueber eine zentrale "whoami"-API)
            |
     Pro-Status (aus subscriptions-Tabelle, siehe echtkosten-mvp/app.js
     -> hasProAccess())
            |
     Ad-Free-Flag auf EchtKosten UND auf EchtJetzt, KaufRadar, LebensRadar

   WICHTIG: Das darf NICHT ueber einfaches localStorage geloest werden, da
   localStorage nicht domainuebergreifend funktioniert (jede Domain hat ihren
   eigenen Speicher). Stattdessen spaeter z.B.:
   - zentrale Auth-API auf echtkosten.de, die per fetch() (mit Cookie oder
     Token) den Pro-Status liefert, oder
   - ein gemeinsames Identity-Provider-Cookie auf einer gemeinsamen
     Ober-Domain, falls technisch/rechtlich sinnvoll umsetzbar.

   TODO FUTURE: echten Cross-Domain-Check hier einbauen, sobald die zentrale
   Authentifizierung auf EchtKosten steht.
   ========================================================================== */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.MEMBERSHIP = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    isProMember: function () {
      // TODO FUTURE: durch echten Cross-Domain-SSO-Check ersetzen.
      return false;
    },
    shouldShowAds: function (adsConfig) {
      var cfg = adsConfig || (typeof window !== "undefined" ? window.ADS_CONFIG : null) || { enabled: true };
      return cfg.enabled === true && this.isProMember() === false;
    }
  };
});
