"use strict";
/* ==========================================================================
   brand.config.js – zentrale Markenkonfiguration
   ==========================================================================
   EINZIGE Stelle, an der der Markenname/Claim/Farbe dieser Website steht.
   Wird von build.js (Node) UND vom Browser (app.js, Templates) genutzt.
   Markenname aendern = nur diese Datei anpassen, dann `node tools/build.js`
   erneut ausfuehren.
   ========================================================================== */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.BRAND_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    siteId: "echtjetzt",
    name: "Geldhirn News",
    claim: "Was heute wirklich zaehlt.",
    tagline: "Nachrichten & Verbraucherthemen – schnell, klar, eingeordnet.",
    domain: "https://news.geldhirn.de",
    themeColor: "#C81E3A",
    backgroundColor: "#FFFFFF",
    newsletterHeadline: "Die wichtigsten Nachrichten des Tages.",
    newsletterSub: "Einmal taeglich die wichtigsten Meldungen aus Geld, Verbraucher, Immobilien und mehr – kostenlos, jederzeit abbestellbar.",
    footerNote: "Geldhirn News ist ein Angebot von Geldhirn – kostenlose Rechner, Ratgeber und Nachrichten rund ums Geld.",
    social: {
      shareText: "Gelesen auf Geldhirn News:"
    }
  };
});
