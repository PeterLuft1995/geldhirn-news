"use strict";
/* ==========================================================================
   ads.config.js – zentrale Werbeflaechen-Konfiguration
   ==========================================================================
   Es ist noch KEIN echter Google-AdSense-Code eingebunden. Alle Werbeflaechen
   laufen ueber die renderAdSlot()-Funktion in tools/build.js (Server-Rendering
   der Platzhalter-Boxen) und werden zusaetzlich client-seitig in app.js anhand
   von isProMember() ein-/ausgeblendet.

   AKTIVIERUNG (spaeter, vor Live-Schaltung):
   1. Google AdSense-Konto fuer diese Domain freischalten lassen.
   2. publisherId unten eintragen (Format "ca-pub-XXXXXXXXXXXXXXXX").
   3. Consent-Management-Platform (CMP) einbinden (siehe README, Abschnitt
      "Cookies/Consent") – AdSense darf ohne Einwilligung nicht personalisiert
      ausgeliefert werden.
   4. In den <head> aller Seiten das offizielle AdSense-Script ergaenzen und
      developmentPlaceholders auf false setzen.
   ========================================================================== */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.ADS_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    enabled: true,
    provider: "adsense",
    /* TODO FUTURE: echte AdSense Publisher-ID eintragen, siehe Hinweis oben. */
    publisherId: "ca-pub-4819706470693982",
    developmentPlaceholders: false,
    slots: {
      belowHero: "below_hero",
      inFeed: "in_feed",
      inArticle: "in_article",
      afterArticle: "after_article",
      sidebar: "sidebar"
    }
  };
});
