"use strict";
/* ==========================================================================
   app.js – EchtJetzt Frontend-Logik
   Reine Vanilla-JS-Interaktivitaet, keine Frameworks/Build-Step noetig.
   ========================================================================== */
(function () {

  function onReady(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }

  /* ---------- Mobile Navigation ---------- */
  function initNavToggle() {
    var toggle = document.querySelector(".nav-toggle");
    var panel = document.getElementById("main-nav-mobile");
    if (!toggle || !panel) return;
    toggle.addEventListener("click", function () {
      var open = panel.classList.toggle("open");
      panel.hidden = !open;
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  /* ---------- Ad-Sichtbarkeit (Pro/Ad-Free-Hook) ---------- */
  function applyAdVisibility() {
    var membership = window.MEMBERSHIP;
    var adsConfig = window.ADS_CONFIG || { enabled: true };
    var show = membership ? membership.shouldShowAds(adsConfig) : adsConfig.enabled !== false;
    document.querySelectorAll(".ad-slot").forEach(function (el) {
      el.hidden = !show;
    });
  }

  /* ---------- Analytics: Ad-Impressions + Klick-Events ---------- */
  function initAnalyticsHooks() {
    var track = window.ANALYTICS && window.ANALYTICS.track ? window.ANALYTICS.track.bind(window.ANALYTICS) : function () {};

    if ("IntersectionObserver" in window) {
      var seen = new WeakSet();
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting && !seen.has(entry.target)) {
            seen.add(entry.target);
            track("ad_impression", { slot: entry.target.getAttribute("data-ad-slot") });
          }
        });
      }, { threshold: 0.5 });
      document.querySelectorAll(".ad-slot").forEach(function (el) { io.observe(el); });
    }

    document.querySelectorAll("[data-analytics-event]").forEach(function (el) {
      el.addEventListener("click", function () {
        track(el.getAttribute("data-analytics-event"), { label: el.getAttribute("data-analytics-label") || null, href: el.getAttribute("href") || null });
      });
    });

    var articleEl = document.querySelector(".article-body");
    if (articleEl) {
      track("article_view", { title: document.title });
    }
  }

  /* ---------- Newsletter (Demo, kein echter Versand) ---------- */
  function initNewsletterForm() {
    var form = document.querySelector('[data-demo-form="newsletter"]');
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var track = window.ANALYTICS && window.ANALYTICS.track;
      if (track) window.ANALYTICS.track("newsletter_signup", { demo: true });
      var btn = form.querySelector("button");
      var original = btn.textContent;
      btn.textContent = "Danke! (Demo)";
      btn.disabled = true;
      setTimeout(function () { btn.textContent = original; btn.disabled = false; form.reset(); }, 2500);
      // TODO FUTURE: echten Versand ueber Webhook -> n8n -> Newsletter-System anstossen.
    });
  }

  /* ---------- Teilen-Buttons ---------- */
  function initShareButtons() {
    document.querySelectorAll("[data-share]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var type = btn.getAttribute("data-share");
        var url = window.location.href;
        var title = document.title;
        if (type === "whatsapp") {
          window.open("https://wa.me/?text=" + encodeURIComponent(title + " " + url), "_blank", "noopener");
        } else if (type === "email") {
          window.location.href = "mailto:?subject=" + encodeURIComponent(title) + "&body=" + encodeURIComponent(url);
        } else if (type === "copy") {
          if (navigator.clipboard) {
            navigator.clipboard.writeText(url).then(function () {
              var original = btn.textContent;
              btn.textContent = "Link kopiert!";
              setTimeout(function () { btn.textContent = original; }, 2000);
            });
          }
        }
      });
    });
  }

  /* ---------- Client-seitige Suche (nutzt search-index.json) ---------- */
  function initSearchPage() {
    var isSearchPage = /suche\.html$/.test(window.location.pathname);
    var resultsEl = document.getElementById("search-results");
    if (!isSearchPage || !resultsEl) return;
    var params = new URLSearchParams(window.location.search);
    var q = (params.get("q") || "").trim().toLowerCase();
    var qEl = document.getElementById("search-query-echo");
    if (qEl) qEl.textContent = q;
    if (!q) { resultsEl.innerHTML = "<p>Bitte gib einen Suchbegriff ein.</p>"; return; }

    var depth = (document.body.getAttribute("data-depth") || "0");
    var prefix = depth === "0" ? "" : "../".repeat(parseInt(depth, 10));

    fetch(prefix + "search-index.json").then(function (r) { return r.json(); }).then(function (items) {
      var matches = items.filter(function (item) {
        var hay = (item.title + " " + item.summary + " " + (item.tags || []).join(" ") + " " + item.category).toLowerCase();
        return hay.indexOf(q) !== -1;
      });
      if (!matches.length) {
        resultsEl.innerHTML = "<p>Keine Treffer fuer „" + q.replace(/</g, "") + "“.</p>";
        return;
      }
      resultsEl.innerHTML = matches.map(function (m) {
        return '<article class="article-card"><div class="article-card-body">' +
          '<div class="article-card-meta"><span class="article-card-cat">' + m.category + '</span></div>' +
          '<h3><a href="' + prefix + m.url + '">' + m.title + '</a></h3><p>' + m.summary + '</p></div></article>';
      }).join("");
    }).catch(function () {
      resultsEl.innerHTML = "<p>Die Suche ist gerade nicht verfuegbar.</p>";
    });
  }

  /* ---------- Service Worker (optional, best effort) ---------- */
  function registerServiceWorker() {
    if (!("serviceWorker" in navigator)) return;
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("/sw.js").catch(function () {});
    });
  }

  onReady(function () {
    initNavToggle();
    applyAdVisibility();
    initAnalyticsHooks();
    initNewsletterForm();
    initShareButtons();
    initSearchPage();
  });
  registerServiceWorker();
})();
